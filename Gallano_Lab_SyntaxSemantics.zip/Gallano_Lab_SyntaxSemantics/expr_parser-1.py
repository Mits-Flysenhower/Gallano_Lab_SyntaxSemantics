expression = ""
pos = 0


def get_current_token():
    global pos, expression
    if pos < len(expression):
        return expression[pos]
    else:
        return None


def eat_token():
    global pos
    char = expression[pos]
    pos += 1
    return char


def factor():
    token = get_current_token()

    if token is not None and token.isdigit():
        number_str = ""
        while get_current_token() is not None and get_current_token().isdigit():
            number_str += eat_token()
        return int(number_str)

    elif token == '(':
        eat_token()
        result = expr()
        if get_current_token() == ')':
            eat_token()
            return result
        else:
            print("ERROR: Missing closing parenthesis ')'")
            raise SyntaxError("Missing ')' near position " + str(pos))

    else:
        print("ERROR: Expecting a number or '(' but got:", token)
        raise SyntaxError("Invalid factor near position " + str(pos))


def term():
    result = factor()

    while get_current_token() == '*' or get_current_token() == '/':
        operator = eat_token()
        next_val = factor()

        if operator == '*':
            result = result * next_val
        else:
            if next_val == 0:
                print("ERROR: Cannot divide by zero")
                raise SyntaxError("Division by zero")
            result = result / next_val

    return result


def expr():
    result = term()

    while get_current_token() == '+' or get_current_token() == '-':
        operator = eat_token()
        next_val = term()

        if operator == '+':
            result = result + next_val
        else:
            result = result - next_val

    return result


def parse_expression(user_input):
    global expression, pos

    expression = user_input.replace(" ", "")
    pos = 0

    try:
        answer = expr()
    except SyntaxError as e:
        print("REJECT: Invalid syntax ->", e)
        return

    if pos == len(expression):
        print("ACCEPT: Valid syntax!")
        print("Result =", answer)
    else:
        leftover = expression[pos:]
        print("REJECT: Leftover input '" + leftover + "' found at position", pos)


def main():
    print("=================================================")
    print(" Recursive Descent Parser - Arithmetic Expressions")
    print(" (supports +, -, *, /, and parentheses)")
    print("=================================================")
    print("Type 'exit' anytime to quit the program.\n")

    while True:
        user_input = input("Enter expression: ")

        if user_input.lower() == "exit":
            print("Goodbye po!")
            break

        if user_input.strip() == "":
            continue

        parse_expression(user_input)
        print()


if __name__ == "__main__":
    main()
